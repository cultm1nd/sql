<?php 
$conn = new mysqli("localhost", "root", "", "base");
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>METANIT.COM</title>
<meta charset="utf-8" />
</head>
<body>
<?php
// если запрос GET
if($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id"]))
{
    $id = $conn->real_escape_string($_GET["id"]);
    $sql = "SELECT * FROM users WHERE id = '$id'";
    if($result = $conn->query($sql))
    {
        if($result->num_rows > 0)
        {
            foreach($result as $row)
            {
                $id= $row["id"];
                $name = $row["name"];
                $login= $row["login"];
                $password= $row["password"];
            }
            echo "<h3>edit user</h3>
                <form method='post'>
                    <input type='hidden' name='id' value='$id' placeholder='id'/><br><br>
                    
                    <input type='text' name='name' value='$name' placeholder='name'/><br><br>
                    
                    <input type='text' name='login' value='$login' placeholder='login' /><br><br>
                    
                    <input type='text' name='password' value='$password' placeholder='password' /><br><br>
                    <input type='submit' value='save' id='bt'>
            </form>";
        }
        else
        {
            echo "<div>user is not defined</div>";
        }
        $result->free();
    } 
    else
    {
        echo "error: " . $conn->error;
    }

}
else if (isset($_POST["id"]) && isset($_POST["name"]) && isset($_POST["login"]) && isset($_POST["password"]))
 {
      
    $id= $conn->real_escape_string($_POST["id"]);
    $name = $conn->real_escape_string($_POST["name"]);
    $login= $conn->real_escape_string($_POST["login"]);
    $password= $conn->real_escape_string($_POST["password"]);
    $sql = "UPDATE users SET name = '$name' ,login='$login' ,password='$password'  WHERE id = '$id'";
    if($result = $conn->query($sql)){
        header("Location: first.php");
    } else{
        echo "error: " . $conn->error;
    }
}
else{
    echo "uncorrect data";
}
$conn->close();
?>
</body>
</html>