<?php
$conn=new mysqli("localhost", "root","","base");
if($conn->connect_error)
{
    die("Ошибка: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>METANIT.COM</title>
<meta charset="utf-8" />
<style>
    #bt{
     border-radius:5px;
     background-color: #6495ED;
     color:white;
     border:none;
    }
    #inp
    {
        border-radius:5px;
        border:none;
        width:200px;
        height:50px;
    }

</style>
</head>
<body>
<form action="create.php" method="post">
    <input type="text" name="name" placeholder="name" id="inp"/><br><br>
    <input type="text" name="login" placeholder="login" id="inp"/><br><br>
    <input type="text" name="password" placeholder="password" id="inp"/><br><br>
    <input type="submit" value="add" id='bt'>
</form>
</body>
</html>
<?php
//добавила данные
if (isset($_POST["name"]) && isset($_POST["login"])&& isset($_POST["password"]))//заполнены ли данные
{

    $name = $conn->real_escape_string($_POST["name"]);
    $login = $conn->real_escape_string($_POST["login"]);
    $password = $conn->real_escape_string($_POST["password"]);
    $sql = "INSERT INTO users (name, login,password) VALUES ('$name', '$login','$password')";
    if($conn->query($sql))
    {
        
    } 
    else
    {
        echo "error: " . $conn->error;
    }
    $conn->close();
}
//вывожу таблицу
$sql = "SELECT * FROM users";
if($result = $conn->query($sql))
{
    $rowsCount = $result->num_rows; // количество полученных строк
    echo "<table><tr><th>id</th><th>name</th><th>login</th><th>password</th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["login"] . "</td>";
            echo "<td>" . $row["password"] . "</td>";
            echo "<td><form action='update.php' method='get'>
                        <input type='hidden' name='id' value='" . $row["id"] . "' />
                        <input type='submit' value='edit' id='bt'>
                </form></td>";
            echo "<td><form action='delete.php' method='post'>
                        <input type='hidden' name='id' value='" . $row["id"] . "' />
                        <input type='submit' value='delete' id='bt'>
                </form></td>";
        echo "</tr>";
        echo "</tr>";
    }
    echo "</table>";
    $result->free();
} 
else
{
    echo "error: " . $conn->error;
}
$conn->close();
?>

