<?php 
$conn = new mysqli("localhost", "root", "", "base");
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>METANIT.COM</title>
<meta charset="utf-8" />
</head>
<body>
<?php
// если запрос GET
if($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id_notes"]))
{
    $noteid = $conn->real_escape_string($_GET["id_notes"]);
    $sql = "SELECT * FROM notes WHERE id_notes = '$id_notes'";
    if($result = $conn->query($sql)){
        if($result->num_rows > 0){
            foreach($result as $row){
                $id_notes = $row["id_notes"];
                $name_notes = $row["name_notes"];
                $id_category = $row["id_category"];
            }
            echo "<h3>Редактировать заметку</h3>
                <form method='post'>
                    <input type='hidden' name='id_notes' value='$id_notes' />
                    <p>Название:</p>
                    <input type='text' name='name_notes' value='$name_notes' /><br><br>
                    <select name="category" id="sel">
                   <option>фильм</option>
                  <option>книга</option>
                   </select><br><br>
                    <input type='submit' value='Сохранить'>
            </form>";
        }
        else{
            echo "<div>Пользователь не найден</div>";
        }
        $result->free();
    } else{
        echo "Ошибка: " . $conn->error;
    }
}
else if (isset($_POST["id_notes"]) && isset($_POST["name_notes"]) && isset($_POST["id_category"])) {
      
    $id_notes= $conn->real_escape_string($_POST["id_notes"]);
    $name_notes = $conn->real_escape_string($_POST["name_notes"]);
    $id_category = $conn->real_escape_string($_POST["id_category"]);
    $sql = "UPDATE notes SET id_notes = '$id_notes', name_notes = '$name_notes' , id_category='$id_category' WHERE id_notes = '$id_notes'";
    if($result = $conn->query($sql)){
        header("Location: notes.php");
    } else{
        echo "Ошибка: " . $conn->error;
    }
}
else{
    echo "Некорректные данные";
}
$conn->close();
?>
</body>
</html>