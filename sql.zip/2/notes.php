<?php 
$conn = new mysqli("localhost", "root", "","base");
if($conn->connect_error){
    die("error: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
    <style>
        h2
        {
           
            text-align:center;
            font-family:Arial;
            color:dark;

        }
        body
        {
            background-color:#DCDCDC;
        }
        main{
            margin-left:150px;
            width:1000px;
            height:300px;
            background-color:white;
            border-radius:10px;
        }
        main #inp{
           width:800px;
           height:40px;
           margin-left:30px;
           border-radius:5px;
           border-width:thin;
           border-color:#DCDCDC;
           
        }
        p{
          margin-left:30px;
          font-family:Arial;
        }
        main #sel{
           width:800px;
           height:40px;
           margin-left:30px;
           border-radius:5px;
           border-color:#DCDCDC;
           
        }
        main #bt{
           width:100px;
           height:40px;
           margin-left:30px;
           border-radius:5px;
           border:none;
           background-color:#0000FF;
           color:white;
           
        }
        </style>
<head>
<title>METANIT.COM</title>
<meta charset="utf-8" />
</head>
<body>
    <main>
<h2>Добавить заметку</h2>
<form action="" method="post">
    <p><b>Название:</b></p>
    <input type="text" name="name" id="inp" />
    <p><b>Категория:</b></p>
    <select name="category" id="sel">
        <option>фильм</option>
        <option>книга</option>
    </select><br><br>
    <input type="submit" value="Добавить" id="bt">
    </main>
</form>
<?php
if (isset($_POST["name"]) && isset($_POST["category"])) {
    $name = $conn->real_escape_string($_POST["name"]);
    $category = $conn->real_escape_string($_POST["category"]);
    $sql = "INSERT INTO notes (name_notes,id_category) VALUES ('$name', $category)";
    if($conn->query($sql))
    {
    }
     else
     {
        echo "Ошибка: " . $conn->error;
    }
}

$sql = "SELECT notes.id_notes,notes.name_notes,category.id_category FROM notes JOIN category on category.id_notes=notes.id_notes where id_category='category'";
if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows; // количество полученных строк
    echo "<p style=''>Заметки</p>";
    echo "<table><tr><th>Название</th><th>Категория</th><th>Редактировать</th><th>Удаление</th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["name_notes"] . "</td>";
            echo "<td>" . $row["category"] . "</td>";
            echo "<td><form action='update3.php' method='get'>
                        <input type='hidden' name='id_notes' value='" . $row["id_notes"] . "' />
                        <input type='submit' value='Редактировать'>
                </form></td>";
            echo "<td><form action='delete2.php' method='post'>
                        <input type='hidden' onclick='return confirm('are you sure?')' name='id_notes' value='" . $row["id_notes"] . "' />
                        <input type='submit' value='Удалить'>
                </form></td>";
        echo "</tr>";
    }
    echo "</table>";
    $result->free();
} else{
    echo "Ошибка: " . $conn->error;
}

$conn->close();
?>