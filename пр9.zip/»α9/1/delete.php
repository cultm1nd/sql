<?php
if(isset($_POST["id"]))
{
    $conn = new mysqli("localhost", "root", "", "borovinskikh");
    if($conn->connect_error){
        die("error: " . $conn->connect_error);
    }
    $id = $conn->real_escape_string($_POST["id"]);
    $sql = "DELETE FROM users WHERE id = '$id'";
    if($conn->query($sql))
    {
         
        header("Location: first.php");
    }
    else
    {
        echo "error: " . $conn->error;
    }
    $conn->close();  
}
?>