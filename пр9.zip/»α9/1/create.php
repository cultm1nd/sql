<?php
if (isset($_POST["name"]) && isset($_POST["login"]) && isset($_POST["password"])) 
{
      
    $conn = new mysqli("localhost", "root", "", "borovinskikh");
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    $name = $conn->real_escape_string($_POST["name"]);
    $login = $conn->real_escape_string($_POST["login"]);
    $password= $conn->real_escape_string($_POST["password"]);
    $sql = "INSERT INTO users (name, login,password) VALUES ('$name', '$login','$password')";
    if($conn->query($sql)){
        echo "data added successfully!";
    } else{
        echo "error: " . $conn->error;
    }
    $conn->close();
}
?>