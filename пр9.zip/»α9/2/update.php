<?php 
$conn = new mysqli("localhost", "root", "", "borovinskikh");
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>METANIT.COM</title>
<style>
    body{
        background-color: #DCDCDC;
    }
.h3
{
    text-align:center;
            font-family:Arial;
            color:dark;
}
</style>
<meta charset="utf-8" />
</head>
<body>
<?php
// если запрос GET
if($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["id_notes"]))
{
    $noteid = $conn->real_escape_string($_GET["id_notes"]);
    $sql = "SELECT id_notes,name_notes,name_category FROM notes,category WHERE id_notes = '$noteid' and notes.id_category=category.id";
    if($result = $conn->query($sql)){
        if($result->num_rows > 0){
            foreach($result as $row){
                $id_notes = $row["id_notes"];
                $name_notes = $row["name_notes"];
                $category = $row["name_category"];
            }
            echo "<h3 class='h3'>Редактировать заметку</h3>
                <form method='post'>
                    <input type='hidden' name='id_notes' value='$id_notes' />
                    <p>Название:
                    <input type='text' name='name_notes' value='$name_notes' /></p>
                    <p>Категория:
                    <select name='category' >
                    <option value='1'>фильм</option>
                    <option value='2'>книга</option>
                    </select></p>
                    <input type='submit' value='Сохранить'>
            </form>";
        }
        else{
            echo "<div>Пользователь не найден</div>";
        }
        $result->free();
    } else{
        echo "Ошибка: " . $conn->error;
    }
}
else if (isset($_POST["id_notes"]) && isset($_POST["name_notes"]) && isset($_POST["category"])) {
      
    $id_notes= $conn->real_escape_string($_POST["id_notes"]);
    $name_notes = $conn->real_escape_string($_POST["name_notes"]);
    $category = $conn->real_escape_string($_POST["category"]);
    $sql = "UPDATE notes SET id_notes = '$id_notes', name_notes = '$name_notes' , id_category='$category' WHERE id_notes = '$id_notes'";
    if($result = $conn->query($sql)){
        header("Location: notes.php");
    } else{
        echo "Ошибка: " . $conn->error;
    }
}
else{
    echo "Некорректные данные";
}
$conn->close();
?>
</body>
</html>