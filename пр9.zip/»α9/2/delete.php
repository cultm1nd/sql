<?php
if(isset($_POST["id_notes"]))
{
    $conn = new mysqli("localhost", "root", "", "borovinskikh");
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    $id_notes = $conn->real_escape_string($_POST["id_notes"]);
    $sql = "DELETE FROM notes WHERE id_notes = '$id_notes'";
    if($conn->query($sql)){
         
        header("Location: notes.php");
    }
    else{
        echo "Ошибка: " . $conn->error;
    }
    $conn->close();  
}
?>