<?php 
$conn = new mysqli("localhost", "root", "","Nikiforova");
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>METANIT.COM</title>
<meta charset="utf-8" />
</head>
<body>
<h2>Добавить заметку</h2>
<form action="" method="post">
    <p>Название:
    <input type="text" name="name" /></p>
    <p>Категория:
    <input type="text" name="cat" /></p>
    <input type="submit" value="Добавить">
</form>
<?php
if (isset($_POST["name"]) && isset($_POST["cat"])) {
    $name = $conn->real_escape_string($_POST["name"]);
    $cat = $conn->real_escape_string($_POST["cat"]);
    $sql = "INSERT INTO notes (name_notes,id_category) VALUES ('$name', $cat)";
    if($conn->query($sql)){
    } else{
        echo "Ошибка: " . $conn->error;
    }
}

$sql = "SELECT notes.id_notes,notes.name_notes,category.id_category FROM notes JOIN category on category.id_notes=notes.id_notes where id_category='category'";
if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows; // количество полученных строк
    echo "<p>Заметки</p>";
    echo "<table><tr><th>Название</th><th>Категория</th><th>Редактировать</th><th>Удаление</th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["name_notes"] . "</td>";
            echo "<td>" . $row["category"] . "</td>";
            echo "<td><form action='update.php' method='get'>
                        <input type='hidden' name='id_notes' value='" . $row["id_notes"] . "' />
                        <input type='submit' value='Редактировать'>
                </form></td>";
            echo "<td><form action='delete.php' method='post'>
                        <input type='hidden' onclick='return confirm('are you sure?')' name='id_notes' value='" . $row["id_notes"] . "' />
                        <input type='submit' value='Удалить'>
                </form></td>";
        echo "</tr>";
    }
    echo "</table>";
    $result->free();
} else{
    echo "Ошибка: " . $conn->error;
}

$conn->close();
?>