<?php 
$conn = new mysqli("localhost", "root", "","Nikiforova");
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html>
<head>
<title>METANIT.COM</title>
<meta charset="utf-8" />
<style>
    #forma{
        border: 1px solid grey;
        padding-left: 5px;
        width: 300px;
        font-family:Arial, Helvetica, sans-serif ;
        font-weight: 600;
    }
    #forma input{
        width: 160px;
    }
    #forma p{
        display: grid;
        width: 250px;
        grid-template-columns: 50% 50%;
    }
    #forma #ii
    {
        width: 100px;
        margin-bottom: 5px;
    }
    table{
        font-size: 16px;
    }
</style>
</head>
<body>
<h2>Добавить пользователя</h2>
<form action="" method="post" id='forma'>
    <p>Имя:
    <input type="text" name="name"/></p>
    <p>Логин:
    <input type="text" name="login" /></p>
    <p>Пароль:
    <input type="text" name="password" /></p>
    <input type="submit" value="Добавить" id='ii'>
</form>
<?php
if (isset($_POST["name"]) && isset($_POST["login"])&& isset($_POST["password"])) {
    $name = $conn->real_escape_string($_POST["name"]);
    $login = $conn->real_escape_string($_POST["login"]);
    $password = $conn->real_escape_string($_POST["password"]);
    $sql = "INSERT INTO users (name,login,password) VALUES ('$name', '$login','$password')";
    if($conn->query($sql)){
    } else{
        echo "Ошибка: " . $conn->error;
    }
}

$sql = "SELECT * FROM users";
if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows; // количество полученных строк
    echo "<p style='font-size:24px;font-weight:600;margin-left:140px'>Пользователи</p>";
    echo "<table style='font-size:20px;' border='1'><tr><th>Имя</th><th>Логин</th><th>Пароль</th><th>Редактировать</th><th>Удаление</th></tr>";
    foreach($result as $row){
        echo "<tr>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["login"] . "</td>";
            echo "<td>" . $row["password"] . "</td>";
            echo "<td><form action='update_form.php' method='get'>
                        <input type='hidden' name='id' value='" . $row["id"] . "' />
                        <input type='submit' value='Редактировать'>
                </form></td>";
            echo "<td><form action='delete_form.php' method='post'>
                        <input type='hidden' name='id' value='" . $row["id"] . "' />
                        <input type='submit' value='Удалить'>
                </form></td>";
        echo "</tr>";
    }
    echo "</table>";
    $result->free();
} else{
    echo "Ошибка: " . $conn->error;
}

$conn->close();
?>